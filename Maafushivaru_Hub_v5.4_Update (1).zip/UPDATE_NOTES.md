# Maafushivaru Document Processing Hub — Update Notes

Version **5.4** (from 5.3)

---

## 1. Supplier name is now read from the correct place

The supplier is taken from the block **between `BUYER'S DEPT.:` and
`SOURCE DOCUMENT NUMBER:`**, exactly as in your example:

```
BUYER'S DEPT.: MAM ACCOUNTING
ALIHAVA CONS'92        <-- name part 1 (OCR damaged "&" into '92)
SUPPLIER:              <-- the label itself is skipped
& TRADING CO           <-- name part 2, below the label
SOURCE DOCUMENT NUMBER:
```

* The lines are joined, the label line is dropped, and the result is matched
  against your configured suppliers, so it resolves to
  **ALIHAVA CONSTRUCTION & TRADING CO PVT LTD**.
* OCR damage is repaired automatically: `CONS'92` and `CONS'9` become `CONS &`,
  `AND` becomes `&`, and punctuation noise is removed.
* Matching is OCR-tolerant: identical names, containment
  (`ALIHAVA CONS & TRADING CO`), split words (`CONS` -> `CONSTRUCTION`), one
  character slips, and the distinctive brand word alone (`ALIHAVA`) all resolve
  to the canonical supplier.
* `BUYER'S DEPT.: MAM ACCOUNTING` can no longer leak into the supplier field,
  and an unknown supplier is returned as raw text for you to correct in the grid.

Verified against your real `config.json` (189 suppliers, 179 invoice formats)
and a synthetic scanned report produced end-to-end with Tesseract.

---

## 2. Online / Offline mode with auto-ingest ON/OFF for both

**Settings → OCR Engines** now contains:

| Control | Options |
|---|---|
| Working mode | `ONLINE (OCR.space API)` / `OFFLINE (local engine)` |
| Auto-ingest | `ON for OFFLINE mode` / `ON for ONLINE mode` |
| Online engine | `Engine 1 Default` / `Engine 2 Enhanced` / `Engine 3 Extra Accurate` |
| Local engines | Tesseract OCR / PaddleOCR / EasyOCR |

* Only one auto-ingest mode can be ON at a time — turning one on turns the other
  off, so a PDF is never processed twice.
* Both switches persist across restarts and are mirrored into the legacy
  `auto_ingest_watcher` key so older configs keep working.
* The header badge and the GRN Dispatch tab always show the engine that will
  actually be used, e.g. `● OFFLINE — Tesseract` or `● ONLINE — OCR.space Engine 3`.

---

## 3. The three OCR.space engines are selectable in ONLINE mode again

The GRN Dispatch selector now lists **six** engines:

```
Online — OCR.space Engine 1 (Default)
Online — OCR.space Engine 2 (Enhanced)
Online — OCR.space Engine 3 (Extra Accurate)
Offline — Tesseract (Local)
Offline — PaddleOCR (Local)   · not installed
Offline — EasyOCR (Local)     · not installed
```

The chosen OCR.space engine is written to `ocr_space.OCREngine`, so the API
call itself changes — not just the label.

---

## 4. Debug window fixed

* The **Run OCR Test** button can no longer disappear. The window is built with
  a grid layout and fixed control columns, the output panels are created before
  the bottom bar, and a long file name can no longer push the button out of view.
* Opening the debugger again **re-uses the existing window** (it is lifted to the
  front) instead of creating a second one — this was why the button stayed
  missing until the app was restarted.
* File list is rebuilt with **↺ Refresh**, and every engine is selectable
  (the three OCR.space engines plus every local engine).
* Missing engines are shown in red with a clear explanation.

---

## 5. Intelligent dependency handling

New file: **`ocr_engine_manager.py`** (must sit next to `maafushivaru_hub.py`).

### First run
On the very first start the software:

1. checks every required library (PyMuPDF, OpenCV, NumPy, Pillow, pytesseract,
   openpyxl, rapidfuzz, watchdog, plyer);
2. asks **which OCR engines to install** (Tesseract / PaddleOCR / EasyOCR /
   OCR.space), with the download size shown for each;
3. installs everything automatically with live progress.

The answer is stored in `app_settings.engine_setup_completed` and
`app_settings.engine_setup_state`, so **the question is never asked again**. If
you install only Tesseract and skip PaddleOCR/EasyOCR, that choice is remembered.

### Later
* Every local engine has an **Install / Reinstall** button in
  **Settings → OCR Engines**.
* `Install all missing` installs every engine that is not present.
* `Run first-time setup again` re-opens the wizard on demand.
* The **About** tab also has Install buttons for the optional dependencies.
* Installing **Tesseract** also installs the Tesseract *program* when possible
  (winget/Chocolatey on Windows, brew on macOS, apt/dnf/pacman on Linux), and
  shows the manual download link when it cannot.

### Engine not found
If the selected engine is not installed you get a clear message —
*"OCR engine not found: PaddleOCR is not installed on this computer. Open
Settings → OCR Engines and press Install…"* — instead of a silent empty result.
The selection is refused and reverted to a working engine, and the run is
blocked (also for auto-ingest) until the engine exists.

### PaddleOCR is isolated in its own venv

PaddleOCR is **not installed into the hub's Python environment**. On Windows,
pressing **Install** next to PaddleOCR automatically creates:

```text
C:\PaddleOCR\venv
```

and installs both `paddlepaddle` and `paddleocr` there. The location is saved in
`config.json` as `paddleocr_install_dir` and `paddleocr_venv_dir`. Every later
run automatically adds that venv's `site-packages` to the PaddleOCR runtime, so
you do not need to activate the venv manually. The configured folder can be
changed later if needed.

---

## 6. Serial scan numbering for a backlog

When the software opens with auto-ingest ON, it no longer waits for a *new*
file. Anything already sitting in `SCANNED` is processed on startup in strict
order:

```
SCAN_0001  ->  SCAN_0002  ->  SCAN_0003  ->  ...
```

* Ordering is by scan number (natural sort), not by file timestamp.
* Files already in the results table are skipped, so a restart never re-does
  finished work.
* `app_settings.serial_scan_next` continues the numbering on the next batch.

---

## Files in this update

| File | Status |
|---|---|
| `maafushivaru_hub.py` | updated |
| `aiextracttab.py` | updated |
| `ocr_engine_manager.py` | **new — required** |
| `config.json` | unchanged (your 189 suppliers / 179 invoice formats are untouched; new keys are added automatically on first start) |

### Compatibility
Your existing `config.json` is migrated automatically: `ocr_engine` becomes
`local_ocr_engine`, `ocr_space.OCREngine` becomes `online_ocr_engine`, and
`auto_ingest_watcher` becomes the OFFLINE auto-ingest switch. No data is lost.

### Requirements
`pip install PyMuPDF opencv-python numpy pillow pytesseract openpyxl rapidfuzz watchdog plyer`
(installed for you automatically on first run if missing).
