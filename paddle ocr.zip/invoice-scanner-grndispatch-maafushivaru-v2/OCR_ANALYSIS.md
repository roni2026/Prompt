# OCR accuracy investigation and tuning notes

## Test document

`SCANNED/Scan 01.pdf` is a 3-page A4 scanned image PDF with a receiving report, an invoice, and a delivery note. It has no embedded text layer, so image OCR is required.

## What was failing

The application's PaddleOCR path passed a **2-D grayscale NumPy array** directly to PaddleOCR 3.x. PaddleOCR 3.7's document preprocessing expects an `H x W x 3` image and raised:

> `IndexError: tuple index out of range`

The generic exception handler then logged that PaddleOCR failed and silently ran Tesseract. This explains why the output looked usable even though the selected engine was not actually producing it.

A second compatibility issue was PaddleOCR/PaddlePaddle selecting a oneDNN/PIR CPU kernel that fails on some builds with `ConvertPirAttribute2RuntimeAttribute not support`. The fixed adapter disables that backend and the optional document-unwarping/orientation stages for these already-upright invoice scans.

## Baseline misses observed

- PaddleOCR's old adapter flattened all recognized tokens into one space-separated paragraph, losing the label/value line structure needed by the existing invoice parser.
- Tesseract at 300 DPI sometimes read `MVR0.00` as `MVRO.00`, `MVR5,000.01` as `MVRS,000.01`, and split supplier/invoice fields across lines depending on PSM.
- Dense table rows and logos produced noise; sparse PSM 11 output recovered some text but damaged reading order.
- On this scan, 400 DPI grayscale/Otsu produced the best field-marker coverage in the benchmark. PaddleOCR at 400 DPI recovered the major fields and values, but its output must be re-grouped by bounding-box position to remain parser-friendly.

## Fixes included

1. PaddleOCR input is converted to 3-channel BGR before inference.
2. Portable CPU settings are used (`device=cpu`, `enable_mkldnn=False`); document unwarping is disabled for these normal flat scans.
3. PaddleOCR can run up to four complementary views: original grayscale-as-BGR, CLAHE, Otsu, and adaptive threshold. The pass with the strongest readable content and invoice markers is selected.
4. PaddleOCR boxes are clustered into reading-order lines instead of being flattened.
5. PaddleOCR only falls back after all configured passes return no usable text or a hard runtime error. The real error is retained in the log.
6. Engine-specific settings are displayed one engine at a time in Settings → OCR Engines.
7. Existing Tesseract report-layout processing remains independent; its PSM/OEM/DPI controls are not applied to PaddleOCR.

## Recommended starting settings

### PaddleOCR (when selected)

| Setting | Recommended | What it changes |
|---|---:|---|
| Passes | 3 | Original + CLAHE + Otsu; 4 adds adaptive threshold |
| Detection side | 2000 | Paddle detection image limit; increase for tiny text at the cost of speed |
| Minimum score | 0.20 | Recognition confidence threshold; lower only when faint text is being dropped |
| Text-line orientation | On | Helps rotated text; can be turned off for faster, known-upright scans |

### Tesseract (when selected)

| Setting | Recommended | What it changes |
|---|---:|---|
| Render DPI | 400 | PDF rasterization resolution; 300 is faster, 400 is more reliable for small print |
| PSM | 6 | Best starting point for invoice/report blocks; try 11 for sparse layouts |
| OEM | 3 | Tesseract's default automatic engine mode |
| Multi-pass | On | Keeps the strongest complementary Tesseract layout when the generic path is used |

These are quality/speed trade-offs, not guarantees: blurred, clipped, skewed, or physically missing characters cannot be recovered by changing OCR settings alone.
